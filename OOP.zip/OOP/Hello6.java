class Hello6 {
	public static void main (String[] args){
	System.out.print("*********\n*\t*\n*\t*\n*\t*\n*********");
	}
}