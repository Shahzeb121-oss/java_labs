//task6
import java.util.Scanner;
class Hello7{
   public static void main (String[] args){
   Scanner scanner = new Scanner(System.in);

   System.out.print("USD : ");
   double USD = scanner.nextDouble();
    int PKR = 280;
   System.out.println("The conversion of USD into PKR : " + (USD * PKR));
    
    
 
    
  


	}
}