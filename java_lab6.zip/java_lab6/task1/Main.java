public class Main {
    public static void main(String[] args){
        Dog d1 = new Dog();
        d1.make_Sound(); 
    }
}