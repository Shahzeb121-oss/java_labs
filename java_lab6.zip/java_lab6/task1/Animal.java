class Animal {
    String Animal;  
    int age;

    public void make_sound() {
        System.out.print("Animal Sound");
    }
}