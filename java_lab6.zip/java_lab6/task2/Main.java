class Main {
    public static void main(String[] args) {
        Graduate graduate_St = new Graduate("Alice Smith", 30, "GS12345", "Artificial Intelligence");
        graduateSt.displayInfo();
    }
}