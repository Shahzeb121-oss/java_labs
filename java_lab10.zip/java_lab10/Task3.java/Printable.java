interface Printable {
    void print();
}