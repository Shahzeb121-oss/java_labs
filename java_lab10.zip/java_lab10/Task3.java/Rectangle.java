class Rectangle extends Shape implements Printable {
    double width;
    double height;

    double area() {
        return width*height;
    }

    public void print() {
    }
}