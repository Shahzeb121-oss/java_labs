abstract class Shape {
    abstract double area();
}

