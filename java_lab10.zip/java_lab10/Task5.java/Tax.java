interface Tax{
void payTax();
}

