class Main{
public static void main(String[] args){
    Duck d = new Duck();
    d.fly(); 
    d.swim();
    }
}
