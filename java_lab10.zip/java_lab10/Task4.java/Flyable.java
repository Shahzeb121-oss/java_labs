interface Flyable {
void fly();
}


   