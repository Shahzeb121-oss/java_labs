class Duck implements Flyable , Swimable{
public void fly() {
System.out.println("The duck is flying.");
}

public void swim(){
System.out.println("The duck is swimming.");
}
}
