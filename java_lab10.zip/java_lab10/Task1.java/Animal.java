abstract class Animal{

	 abstract void make_sound();

	 public void eat(){
	 	System.out.println("Animal is eating.");
	 }
}