class Main{
	public static void main(String[] args){
		Dog d = new Dog();
		Cat c = new Cat();
        
        d.eat();
		d.make_sound();
		
		c.eat();
		c.make_sound();
	}
}