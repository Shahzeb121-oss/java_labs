class Dog extends Animal {
	
	public void make_sound(){
		System.out.println("Dog is eating bones.");
	}
}