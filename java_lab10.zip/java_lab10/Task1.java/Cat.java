class Cat extends Animal {
	
	public void make_sound(){
		System.out.println("Cat is eating fish.");
	}
}