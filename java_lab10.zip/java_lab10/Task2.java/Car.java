class Car implements Vehicle{
	public void start(){
	System.out.println("The car is started.");
	}

	public void stop(){
	System.out.println("Brakes are applied, car is stopped.");
	}
}