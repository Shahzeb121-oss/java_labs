class Bike implements Vehicle{
	public void start(){
	System.out.println("The bike is started.");
	}

	public void stop(){
	System.out.println("Brakes are applied, bike is stopped.");
	}
}